"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resetRegistry = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_s3_1 = require("@aws-sdk/client-s3");
// Initialize clients
const dynamoDBClient = new client_dynamodb_1.DynamoDBClient({ region: "us-west-2" });
const dynamoDBDocClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDBClient);
const s3Client = new client_s3_1.S3Client({ region: "us-west-2" });
// Constants for default user and AWS resource names
const DEFAULT_USERNAME = "ece30861defaultadminuser";
const DEFAULT_PASSWORD = "correcthorsebatterystaple123(!__+@**(A;DROP TABLE packages";
const DYNAMODB_TABLE_NAME = "PackagesTable"; // Change this to your table name
const S3_BUCKET_NAME = "your-s3-bucket-name"; // Change this to your S3 bucket name
const resetRegistry = async (event) => {
    try {
        // Delete all items in DynamoDB table (or delete and recreate if simpler)
        await deleteDynamoDBTable();
        await delay(5000); // Wait 5 seconds for table deletion
        await createDynamoDBTable();
        // Clear S3 bucket
        await clearS3Bucket();
        // Re-add default user to the system (implementation depends on your auth setup)
        await addDefaultUser();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Registry reset to default state." }),
        };
    }
    catch (error) {
        const err = error;
        console.error("Error resetting registry:", err.message || err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Failed to reset registry." }),
        };
    }
};
exports.resetRegistry = resetRegistry;
// Helper function to add delay between DynamoDB table delete and recreate
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
async function deleteDynamoDBTable() {
    try {
        // Check if table exists
        await dynamoDBClient.send(new client_dynamodb_1.DescribeTableCommand({ TableName: DYNAMODB_TABLE_NAME }));
        // If it exists, proceed to delete
        await dynamoDBClient.send(new client_dynamodb_1.DeleteTableCommand({ TableName: DYNAMODB_TABLE_NAME }));
        console.log(`Table ${DYNAMODB_TABLE_NAME} deleted successfully.`);
    }
    catch (error) {
        const err = error;
        // If error is "ResourceNotFoundException", the table doesn't exist
        if (err.name === "ResourceNotFoundException") {
            console.log(`Table ${DYNAMODB_TABLE_NAME} does not exist. Skipping delete.`);
        }
        else {
            console.error("Error deleting DynamoDB table:", err.message || error);
        }
    }
}
async function createDynamoDBTable() {
    try {
        await dynamoDBClient.send(new client_dynamodb_1.CreateTableCommand({
            TableName: DYNAMODB_TABLE_NAME,
            KeySchema: [
                { AttributeName: "Name", KeyType: "HASH" }, // Partition key
                { AttributeName: "Version", KeyType: "RANGE" }, // Sort key
            ],
            AttributeDefinitions: [
                { AttributeName: "Name", AttributeType: "S" },
                { AttributeName: "Version", AttributeType: "S" },
            ],
            ProvisionedThroughput: {
                ReadCapacityUnits: 5,
                WriteCapacityUnits: 5,
            },
        }));
    }
    catch (error) {
        const err = error;
        console.error("Error creating DynamoDB table:", err.message || error);
    }
}
async function clearS3Bucket() {
    try {
        const listCommand = new client_s3_1.ListObjectsCommand({ Bucket: S3_BUCKET_NAME });
        const objects = await s3Client.send(listCommand);
        if (objects.Contents && objects.Contents.length > 0) {
            const deleteCommand = new client_s3_1.DeleteObjectsCommand({
                Bucket: S3_BUCKET_NAME,
                Delete: { Objects: objects.Contents.map((obj) => ({ Key: obj.Key })) },
            });
            await s3Client.send(deleteCommand);
        }
    }
    catch (error) {
        const err = error;
        console.error("Error clearing S3 bucket:", err.message || error);
    }
}
async function addDefaultUser() {
    const defaultUser = {
        TableName: DYNAMODB_TABLE_NAME,
        Item: {
            Username: DEFAULT_USERNAME,
            Password: DEFAULT_PASSWORD,
            Role: "admin",
        },
    };
    try {
        await dynamoDBDocClient.send(new lib_dynamodb_1.PutCommand(defaultUser));
    }
    catch (error) {
        const err = error;
        console.error("Error adding default user:", err.message || error);
    }
}
