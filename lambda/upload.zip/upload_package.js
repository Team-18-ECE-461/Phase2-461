"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.lambdaHandler = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const axios_1 = __importDefault(require("axios"));
const jszip_1 = __importDefault(require("jszip"));
const get_github_url_1 = __importDefault(require("get-github-url"));
const crypto = __importStar(require("crypto"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const esbuild = __importStar(require("esbuild"));
const os_1 = require("os");
const archiver_1 = __importDefault(require("archiver"));
const unzipper_1 = __importDefault(require("unzipper"));
const stream_1 = __importDefault(require("stream"));
const tar = __importStar(require("tar"));
async function urlhandler(url) {
    var _a;
    if (url.includes('github')) {
        const repoNameMatch = url.match(/github\.com\/[^\/]+\/([^\/]+)/);
        if (repoNameMatch && repoNameMatch[1]) {
            return url;
        }
    }
    else if (url.includes('npm')) {
        try {
            const match = url.match(/\/package\/([^\/]+)/); // Match the pattern
            const packageName = match ? match[1] : null;
            const response = await axios_1.default.get(`https://registry.npmjs.org/${packageName}`, { responseType: 'json' });
            const repositoryUrl = (_a = response.data.repository) === null || _a === void 0 ? void 0 : _a.url;
            if (repositoryUrl) {
                url = (0, get_github_url_1.default)(repositoryUrl);
            }
            else {
                throw new Error('No repository URL found');
            }
            const repoNameMatch = url.match(/github\.com\/[^\/]+\/([^\/]+)/);
            if (repoNameMatch && repoNameMatch[1]) {
                return url;
            }
        }
        catch (error) {
            console.error(`Error fetching package data: ${error}`);
        }
    }
}
const s3 = new client_s3_1.S3();
const dynamoDBclient = new client_dynamodb_1.DynamoDBClient({});
const BUCKET_NAME = 'packagesstorage';
const TABLE_NAME = 'PackageInfo';
const lambdaHandler = async (event) => {
    try {
        const requestBody = JSON.parse(event.body);
        let content = requestBody.Content;
        let url = requestBody.URL;
        const JSProgram = requestBody.JSProgram;
        let name = requestBody.Name;
        let debloat = requestBody.Debloat;
        // Check if either content or url is set, but not both
        if ((!content && !url) || (content && url) || content && name.length === 0) {
            return {
                statusCode: 400,
                body: JSON.stringify('Invalid Request Body!'),
            };
        }
        let packagePath = null;
        let version = null;
        let packagedebloatName = null;
        if (debloat) {
            const tempDir = await fs_1.default.promises.mkdtemp(path_1.default.join((0, os_1.tmpdir)(), 'package-'));
            if (url) {
                [packagePath, version, packagedebloatName] = await downloadAndExtractNpmPackage(url, tempDir);
            }
            else if (content) {
                packagePath = await extractBase64ZipContent(content, tempDir);
                packagedebloatName = name;
                version = '1.0.0';
            }
            const outputDir = path_1.default.join(tempDir, 'debloated');
            fs_1.default.mkdirSync(outputDir, { recursive: true });
            await esbuild.build({
                entryPoints: [path_1.default.join(packagePath, 'index.js')], // Adjust main entry file if necessary
                bundle: true,
                outdir: outputDir,
                minify: true,
                treeShaking: true,
            });
            const debloatedZipPath = path_1.default.join(tempDir, 'debloated.zip');
            await zipFolder(outputDir, debloatedZipPath);
            const uploadkey = `${packagedebloatName}-${version}`;
            const debloatID = generatePackageId(packagedebloatName, version);
            if (await checkexistingPackage(packagedebloatName, version) === false) {
                await uploadToS3(debloatedZipPath, BUCKET_NAME, uploadkey);
                await cleanupTempFiles(tempDir);
            }
            else {
                await cleanupTempFiles(tempDir);
                return {
                    statusCode: 409,
                    body: JSON.stringify('Package already exists'),
                };
            }
            await uploadDB(debloatID, packagedebloatName, version, JSProgram, url);
            return {
                statusCode: 201,
                body: JSON.stringify({
                    metadata: {
                        Name: packagedebloatName,
                        Version: version,
                        ID: debloatID,
                    },
                    data: {
                        Content: content,
                        URL: url,
                        JSProgram: JSProgram,
                    },
                }),
            };
        }
        else { //no debloat
            // Retrieve zip file contents
            let zipBuffer;
            if (content) {
                zipBuffer = Buffer.from(content, 'base64');
            }
            else if (url) {
                const response = await axios_1.default.get(`${url}/archive/refs/heads/main.zip`, { responseType: 'arraybuffer' });
                zipBuffer = Buffer.from(response.data);
            }
            else {
                throw new Error('No content or URL provided');
            }
            // Load zip content to inspect package.json
            const zip = await jszip_1.default.loadAsync(zipBuffer);
            console.log("here: after debloat");
            content = zipBuffer.toString('base64');
            let tpackageJsonFile = null;
            zip.forEach((relativePath, file) => {
                if (relativePath.endsWith('package.json')) {
                    tpackageJsonFile = zip.file(relativePath); // Capture the relative path to package.json
                }
            });
            const packageJsonFile = tpackageJsonFile;
            let packageName = name; // Default package name if content is provided
            let packageVersion = '1.0.0'; // Default package version if content is provided
            //if url provided, get package name and version from package.json
            if (packageJsonFile && url) {
                const packageJsonContent = await packageJsonFile.async('string');
                const packageInfo = JSON.parse(packageJsonContent);
                packageName = packageInfo.name || 'Undefined';
                packageVersion = packageInfo.version || '1.0.0';
            }
            // Generate package ID
            const packageId = generatePackageId(packageName, packageVersion);
            //key for S3 bucket
            let key = `${packageName}-${packageVersion}`;
            // Check if the package already exists in DynamoDB
            const existingPackage = await dynamoDBclient.send(new client_dynamodb_1.QueryCommand({
                TableName: TABLE_NAME,
                KeyConditionExpression: '#name = :name and Version = :version',
                ExpressionAttributeNames: {
                    '#name': 'Name', // Alias for reserved keyword 'Name'
                },
                ExpressionAttributeValues: {
                    ':name': { S: packageName },
                    ':version': { S: packageVersion },
                },
            }));
            if (existingPackage.Items && existingPackage.Items.length > 0) {
                return {
                    statusCode: 409, // Conflict
                    body: JSON.stringify({
                        message: 'Package already exists',
                        package: existingPackage.Items,
                    }),
                };
            }
            // Upload zip file to S3 if the package does not already exist
            await s3.putObject({
                Bucket: BUCKET_NAME,
                Key: key,
                Body: zipBuffer,
                ContentType: 'application/zip',
            });
            // Save package details to DynamoDB
            uploadDB(packageId, packageName, packageVersion, JSProgram, url);
            return {
                statusCode: 201,
                body: JSON.stringify({
                    metadata: {
                        Name: packageName,
                        Version: packageVersion,
                        ID: packageId,
                    },
                    data: {
                        Content: content,
                        URL: url,
                        JSProgram: JSProgram,
                    },
                }),
            };
        }
    }
    catch (error) {
        console.error('Error processing request:', error);
        return {
            statusCode: 500,
            body: JSON.stringify('Failed to process the request.'),
        };
    }
};
exports.lambdaHandler = lambdaHandler;
function versionInt(version) {
    const [major, minor, patch] = version.split('.').map(Number);
    return major * 1000000 + minor * 1000 + patch;
}
async function downloadAndExtractNpmPackage(npmUrl, destination) {
    // Convert npm URL to registry API URL
    const packageName = npmUrl.split('/').pop();
    const registryUrl = `https://registry.npmjs.org/${packageName}`;
    // Fetch package metadata
    const response = await axios_1.default.get(registryUrl);
    const latestVersion = response.data['dist-tags'].latest;
    const tarballUrl = response.data.versions[latestVersion].dist.tarball;
    // Download the tarball
    const tarballPath = path_1.default.join(destination, 'package.tgz');
    const writer = fs_1.default.createWriteStream(tarballPath);
    const downloadResponse = await axios_1.default.get(tarballUrl, { responseType: 'stream' });
    await new Promise((resolve, reject) => {
        downloadResponse.data.pipe(writer);
        writer.on('finish', resolve);
        writer.on('error', reject);
    });
    // Extract tarball
    await tar.extract({ file: tarballPath, cwd: destination });
    return [path_1.default.join(destination, 'package'), latestVersion, packageName]; // Adjust this based on the extracted directory structure
}
function generatePackageId(name, version) {
    const hash = crypto.createHash('sha256');
    hash.update(`${name}-${version}`);
    return hash.digest('hex').slice(0, 12); // Truncate for a shorter ID
}
// Function to clean up temporary files
async function cleanupTempFiles(tempFilePath) {
    if (fs_1.default.existsSync(tempFilePath)) {
        fs_1.default.unlinkSync(tempFilePath);
    }
}
async function createOptimizedZipStream(zipBuffer, ignoredPatterns) {
    const buffers = [];
    const optimizedZipStream = (0, archiver_1.default)('zip', { zlib: { level: 9 } });
    // Collect data into the buffer array as it is generated
    optimizedZipStream.on('data', (data) => buffers.push(data));
    const zipStream = new stream_1.default.PassThrough();
    zipStream.end(zipBuffer);
    const zipContents = zipStream.pipe(unzipper_1.default.Parse({ forceStream: true }));
    zipContents.on('entry', (entry) => {
        const shouldIgnore = ignoredPatterns.some((pattern) => entry.path.includes(pattern));
        if (!shouldIgnore) {
            optimizedZipStream.append(entry, { name: entry.path });
        }
        else {
            entry.autodrain();
        }
    });
    // Ensure the archive finalizes once done
    await new Promise((resolve, reject) => {
        zipContents.on('close', resolve);
        zipContents.on('error', reject);
    });
    optimizedZipStream.finalize();
    // Return combined data as a Buffer
    return Buffer.concat(buffers);
}
async function extractBase64ZipContent(base64Content, destination) {
    const zipPath = path_1.default.join(destination, 'package.zip');
    const buffer = Buffer.from(base64Content, 'base64');
    await fs_1.default.promises.writeFile(zipPath, buffer);
    // Extract zip content
    await fs_1.default.createReadStream(zipPath)
        .pipe(unzipper_1.default.Extract({ path: destination }))
        .promise();
    return path_1.default.join(destination, 'package'); // Adjust based on zip structure
}
async function zipFolder(source, out) {
    const archive = fs_1.default.createWriteStream(out);
    const zipper = (0, archiver_1.default)('zip', {
        zlib: { level: 9 } // High compression level
    });
    zipper.pipe(archive);
    zipper.directory(source, false);
    await zipper.finalize();
}
async function uploadToS3(filePath, bucketName, key) {
    const fileStream = fs_1.default.createReadStream(filePath);
    await s3.putObject({
        Bucket: bucketName,
        Key: key,
        Body: fileStream,
        ContentType: 'application/zip',
    });
}
async function checkexistingPackage(packageName, packageVersion) {
    const existingPackage = await dynamoDBclient.send(new client_dynamodb_1.QueryCommand({
        TableName: TABLE_NAME,
        KeyConditionExpression: '#name = :name and Version = :version',
        ExpressionAttributeNames: {
            '#name': 'Name', // Alias for reserved keyword 'Name'
        },
        ExpressionAttributeValues: {
            ':name': { S: packageName },
            ':version': { S: packageVersion },
        },
    }));
    if (existingPackage.Items && existingPackage.Items.length > 0) {
        return true;
    }
    return false;
}
async function uploadDB(packageId, packageName, packageVersion, JSProgram, url) {
    const item = {
        ID: { S: packageId },
        Name: { S: packageName },
        Version: { S: packageVersion },
        VersionInt: { N: versionInt(packageVersion).toString() },
        JSProgram: { S: JSProgram },
        CreatedAt: { S: new Date().toISOString() },
        URL: { S: url },
    };
    await dynamoDBclient.send(new client_dynamodb_1.PutItemCommand({
        TableName: TABLE_NAME,
        Item: item
    }));
}
