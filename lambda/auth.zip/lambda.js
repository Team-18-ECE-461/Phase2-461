const lambdaHandler = async (event) => {
    return {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    }
}
exports.lambdaHandler = lambdaHandler;