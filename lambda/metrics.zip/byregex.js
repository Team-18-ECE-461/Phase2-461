"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lambdaHandler = void 0;
const lambdaHandler = async (event) => {
    console.log('event', event);
    return {
        statusCode: 200,
        body: event.body
    };
};
exports.lambdaHandler = lambdaHandler;
